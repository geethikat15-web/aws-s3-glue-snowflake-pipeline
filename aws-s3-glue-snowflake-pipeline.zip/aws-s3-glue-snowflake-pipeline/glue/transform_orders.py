"""PySpark job (runs on AWS Glue): clean raw orders and write partitioned Parquet.

Steps: read CSV -> standardize types -> drop duplicates -> drop invalid rows
       -> add derived columns -> write Parquet partitioned by order_month.

Glue arguments: --input_path, --output_path
"""
import sys

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F


def transform(df: DataFrame) -> DataFrame:
    """Pure transformation, kept separate so it can be tested locally."""
    cleaned = (
        df.withColumn("order_date", F.to_date("order_date"))
        .withColumn("quantity", F.col("quantity").cast("int"))
        .withColumn("unit_price", F.col("unit_price").cast("decimal(10,2)"))
        .withColumn("status", F.upper(F.trim("status")))
        .dropDuplicates(["order_id"])
        .filter(F.col("order_id").isNotNull())
        .filter(F.col("quantity") > 0)
        .filter(F.col("unit_price") >= 0)
    )
    return (
        cleaned.withColumn("total_amount", (F.col("quantity") * F.col("unit_price")).cast("decimal(12,2)"))
        .withColumn("order_month", F.date_format("order_date", "yyyy-MM"))
        .withColumn("is_cancelled", (F.col("status") == "CANCELLED"))
    )


def main(input_path: str, output_path: str) -> None:
    spark = SparkSession.builder.appName("transform_orders").getOrCreate()
    raw = spark.read.option("header", True).csv(input_path)
    raw_count = raw.count()

    result = transform(raw)
    clean_count = result.count()
    print(f"Rows read: {raw_count}, rows kept: {clean_count}, removed: {raw_count - clean_count}")

    result.write.mode("append").partitionBy("order_month").parquet(output_path)
    spark.stop()


if __name__ == "__main__":
    try:
        from awsglue.utils import getResolvedOptions  # available on AWS Glue
        args = getResolvedOptions(sys.argv, ["input_path", "output_path"])
        main(args["input_path"], args["output_path"])
    except ImportError:
        # Local run: python glue/transform_orders.py data/sample/orders.csv output/
        main(sys.argv[1], sys.argv[2])
