-- Load curated Parquet files from S3 into Snowflake.
-- Replace the placeholders (<...>) with your own values.

USE ROLE ACCOUNTADMIN;

CREATE DATABASE IF NOT EXISTS ORDERS_DB;
CREATE SCHEMA IF NOT EXISTS ORDERS_DB.CURATED;
USE SCHEMA ORDERS_DB.CURATED;

-- Secure access to S3 via an IAM role (no keys stored in Snowflake)
CREATE STORAGE INTEGRATION IF NOT EXISTS s3_orders_int
  TYPE = EXTERNAL_STAGE
  STORAGE_PROVIDER = 'S3'
  ENABLED = TRUE
  STORAGE_AWS_ROLE_ARN = '<arn:aws:iam::ACCOUNT_ID:role/snowflake-s3-access>'
  STORAGE_ALLOWED_LOCATIONS = ('s3://<your-curated-bucket>/orders/');

-- Run DESC INTEGRATION s3_orders_int; and copy STORAGE_AWS_IAM_USER_ARN and
-- STORAGE_AWS_EXTERNAL_ID into the trust policy of the IAM role above.

CREATE FILE FORMAT IF NOT EXISTS parquet_ff TYPE = PARQUET;

CREATE STAGE IF NOT EXISTS orders_stage
  URL = 's3://<your-curated-bucket>/orders/'
  STORAGE_INTEGRATION = s3_orders_int
  FILE_FORMAT = parquet_ff;

CREATE TABLE IF NOT EXISTS orders (
    order_id         NUMBER,
    customer_id      STRING,
    order_date       DATE,
    product_category STRING,
    quantity         NUMBER,
    unit_price       NUMBER(10,2),
    status           STRING,
    total_amount     NUMBER(12,2),
    is_cancelled     BOOLEAN,
    order_month      STRING,
    loaded_at        TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
);

-- COPY INTO skips files already loaded, so it is safe to re-run
COPY INTO orders (order_id, customer_id, order_date, product_category, quantity,
                  unit_price, status, total_amount, is_cancelled, order_month)
FROM (
    SELECT $1:order_id, $1:customer_id, $1:order_date, $1:product_category, $1:quantity,
           $1:unit_price, $1:status, $1:total_amount, $1:is_cancelled, $1:order_month
    FROM @orders_stage
)
ON_ERROR = 'ABORT_STATEMENT';

-- Quality check: no duplicate orders after load
SELECT order_id, COUNT(*) AS copies
FROM orders
GROUP BY order_id
HAVING COUNT(*) > 1;

-- Example analytics query
SELECT order_month, product_category,
       SUM(total_amount) AS revenue,
       COUNT(*)          AS orders
FROM orders
WHERE NOT is_cancelled
GROUP BY order_month, product_category
ORDER BY order_month, revenue DESC;
