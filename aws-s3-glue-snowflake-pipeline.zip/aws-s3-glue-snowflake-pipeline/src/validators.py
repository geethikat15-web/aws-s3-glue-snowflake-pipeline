"""Reusable data-quality checks used by the Lambda trigger and the tests."""
import pandas as pd

REQUIRED_COLUMNS = [
    "order_id", "customer_id", "order_date",
    "product_category", "quantity", "unit_price", "status",
]
VALID_STATUSES = {"PLACED", "SHIPPED", "DELIVERED", "CANCELLED"}


def check_schema(df: pd.DataFrame) -> list[str]:
    """Return a list of problems with the columns (empty list = OK)."""
    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    return [f"missing column: {c}" for c in missing]


def check_rows(df: pd.DataFrame) -> list[str]:
    """Return a list of row-level problems (empty list = OK)."""
    problems = []
    if df.empty:
        return ["file has no rows"]
    if df["order_id"].isnull().any():
        problems.append("null order_id values found")
    if (pd.to_numeric(df["quantity"], errors="coerce") <= 0).any():
        problems.append("quantity must be greater than 0")
    if (pd.to_numeric(df["unit_price"], errors="coerce") < 0).any():
        problems.append("unit_price cannot be negative")
    if pd.to_datetime(df["order_date"], errors="coerce").isnull().any():
        problems.append("invalid order_date values found")
    bad_status = set(df["status"].dropna().str.upper()) - VALID_STATUSES
    if bad_status:
        problems.append(f"unexpected status values: {sorted(bad_status)}")
    return problems


def validate(df: pd.DataFrame) -> list[str]:
    """Run all checks. Returns all problems found."""
    schema_problems = check_schema(df)
    if schema_problems:
        return schema_problems
    return check_rows(df)
