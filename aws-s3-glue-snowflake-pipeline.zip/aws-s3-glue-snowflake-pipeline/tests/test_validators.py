import pandas as pd

from src.validators import validate

GOOD = pd.DataFrame({
    "order_id": [1, 2],
    "customer_id": ["C1", "C2"],
    "order_date": ["2024-03-01", "2024-03-02"],
    "product_category": ["Books", "Home"],
    "quantity": [1, 2],
    "unit_price": [10.0, 20.0],
    "status": ["SHIPPED", "DELIVERED"],
})


def test_valid_file_passes():
    assert validate(GOOD) == []


def test_missing_column_is_reported():
    assert "missing column: status" in validate(GOOD.drop(columns=["status"]))


def test_negative_price_is_reported():
    df = GOOD.copy()
    df.loc[0, "unit_price"] = -5
    assert "unit_price cannot be negative" in validate(df)


def test_zero_quantity_is_reported():
    df = GOOD.copy()
    df.loc[0, "quantity"] = 0
    assert "quantity must be greater than 0" in validate(df)


def test_bad_date_is_reported():
    df = GOOD.copy()
    df.loc[0, "order_date"] = "not-a-date"
    assert "invalid order_date values found" in validate(df)


def test_unknown_status_is_reported():
    df = GOOD.copy()
    df.loc[0, "status"] = "LOST"
    assert any("unexpected status" in p for p in validate(df))


def test_empty_file_is_reported():
    assert validate(GOOD.iloc[0:0]) == ["file has no rows"]
