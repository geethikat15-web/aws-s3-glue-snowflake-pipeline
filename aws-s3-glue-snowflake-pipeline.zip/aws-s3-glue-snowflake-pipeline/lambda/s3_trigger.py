"""AWS Lambda: runs when a file lands in the raw S3 bucket.

1. Downloads the CSV and validates it.
2. Valid file   -> starts the Glue transformation job.
3. Invalid file -> moves it to the quarantine/ prefix and logs the problems.

Environment variables: GLUE_JOB_NAME
"""
import io
import json
import logging
import os
import urllib.parse

import boto3
import pandas as pd

from src.validators import validate

logger = logging.getLogger()
logger.setLevel(logging.INFO)

s3 = boto3.client("s3")
glue = boto3.client("glue")


def lambda_handler(event, context):
    results = []
    for record in event["Records"]:
        bucket = record["s3"]["bucket"]["name"]
        key = urllib.parse.unquote_plus(record["s3"]["object"]["key"])
        logger.info("New file: s3://%s/%s", bucket, key)

        body = s3.get_object(Bucket=bucket, Key=key)["Body"].read()
        df = pd.read_csv(io.BytesIO(body))
        problems = validate(df)

        if problems:
            quarantine_key = f"quarantine/{os.path.basename(key)}"
            s3.copy_object(Bucket=bucket, Key=quarantine_key,
                           CopySource={"Bucket": bucket, "Key": key})
            s3.delete_object(Bucket=bucket, Key=key)
            logger.error("Validation failed for %s: %s", key, problems)
            results.append({"file": key, "status": "QUARANTINED", "problems": problems})
            continue

        run = glue.start_job_run(
            JobName=os.environ["GLUE_JOB_NAME"],
            Arguments={"--input_path": f"s3://{bucket}/{key}"},
        )
        logger.info("Started Glue run %s for %s", run["JobRunId"], key)
        results.append({"file": key, "status": "STARTED", "run_id": run["JobRunId"]})

    return {"statusCode": 200, "body": json.dumps(results)}
