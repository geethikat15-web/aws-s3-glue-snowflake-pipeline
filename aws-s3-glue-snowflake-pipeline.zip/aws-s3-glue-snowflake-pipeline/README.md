# AWS Serverless Orders Pipeline (S3 · Lambda · Glue/PySpark · Snowflake)

An event-driven data pipeline. When a CSV lands in S3, a Lambda function validates it, a PySpark job on AWS Glue cleans it, and the curated Parquet output is loaded into Snowflake for analytics.

**Stack:** AWS S3, Lambda, Glue, PySpark, IAM, Terraform, Snowflake, Python, GitHub Actions

## Architecture

```
CSV lands in S3 (raw bucket)
        |
        v  S3 event
Lambda: validate file
   |-- invalid -> moved to quarantine/ and logged
   |-- valid   -> starts Glue job
                    |
                    v
        Glue (PySpark): clean, dedupe, derive columns
                    |
                    v
        S3 curated bucket (Parquet, partitioned by order_month)
                    |
                    v  storage integration + external stage
        Snowflake: COPY INTO ORDERS table -> analytics queries
```

## Project structure

| Path | Purpose |
|---|---|
| `lambda/s3_trigger.py` | Validates new files, quarantines bad ones, starts the Glue job |
| `glue/transform_orders.py` | PySpark transformation (type casting, dedupe, filtering, derived columns, partitioned Parquet) |
| `src/validators.py` | Reusable data-quality checks (schema, nulls, ranges, dates, statuses) |
| `tests/` | Unit tests for the validators (run with pytest) |
| `snowflake/load_from_s3.sql` | Storage integration, external stage, `COPY INTO`, quality and analytics queries |
| `terraform/main.tf` | S3 buckets (public access blocked), IAM role, Glue job |
| `data/sample/orders.csv` | Small synthetic sample (includes one duplicate row and one cancelled order) |
| `.github/workflows/ci.yml` | Runs the tests on every push and pull request |

## Data quality

- **Before processing:** schema check, null keys, quantity > 0, price >= 0, valid dates, allowed statuses. Failing files are quarantined, not processed.
- **During processing:** duplicates removed by `order_id`; invalid rows filtered; row counts printed (read vs kept vs removed).
- **After loading:** Snowflake query checks for duplicate orders.

## Run the tests locally

```bash
pip install -r requirements.txt
python -m pytest -q
```

## Run the Spark transformation locally

```bash
python glue/transform_orders.py data/sample/orders.csv output/
```

(Requires Java and `pyspark`. Of 8 sample rows, 1 duplicate is removed, leaving 7.)

## Deploy (outline)

1. `cd terraform && terraform init && terraform apply` to create the buckets, role, and Glue job.
2. Upload `glue/transform_orders.py` to `s3://<raw-bucket>/scripts/`.
3. Package `lambda/s3_trigger.py` and `src/` with `pandas` (Lambda layer) and set `GLUE_JOB_NAME`.
4. Add an S3 event notification on the raw bucket to invoke the Lambda.
5. Run `snowflake/load_from_s3.sql` after replacing the `<placeholders>`.

## Notes

All data is synthetic. Never commit AWS keys or Snowflake passwords.
